---
name: Culinary Intelligence
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daef'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e1e8fd'
  surface-container-highest: '#dce2f7'
  on-surface: '#141b2b'
  on-surface-variant: '#42493e'
  inverse-surface: '#293040'
  inverse-on-surface: '#edf0ff'
  outline: '#72796e'
  outline-variant: '#c2c9bb'
  surface-tint: '#3b6934'
  primary: '#154212'
  on-primary: '#ffffff'
  primary-container: '#2d5a27'
  on-primary-container: '#9dd090'
  inverse-primary: '#a1d494'
  secondary: '#5f5f58'
  on-secondary: '#ffffff'
  secondary-container: '#e2e0d7'
  on-secondary-container: '#64635c'
  tertiary: '#5f2a15'
  on-tertiary: '#ffffff'
  tertiary-container: '#7b4029'
  on-tertiary-container: '#ffb094'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcf0ae'
  primary-fixed-dim: '#a1d494'
  on-primary-fixed: '#002201'
  on-primary-fixed-variant: '#23501e'
  secondary-fixed: '#e5e2da'
  secondary-fixed-dim: '#c9c6be'
  on-secondary-fixed: '#1c1c17'
  on-secondary-fixed-variant: '#474741'
  tertiary-fixed: '#ffdbcf'
  tertiary-fixed-dim: '#ffb59b'
  on-tertiary-fixed: '#380d00'
  on-tertiary-fixed-variant: '#703721'
  background: '#f9f9ff'
  on-background: '#141b2b'
  surface-variant: '#dce2f7'
  basil-green: '#2D5A27'
  tomato-red: '#E4967A'
  parchment: '#F5F2E9'
  charcoal: '#111827'
  sage-tint: '#E8F0E7'
  slate-gray: '#6B7280'
typography:
  display-lg:
    fontFamily: Source Serif 4
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Source Serif 4
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Source Serif 4
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Source Serif 4
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 64px
---

## Brand & Style

The design system is centered on a "Digital Kitchen" philosophy: a space that feels as clean and organized as a professional chef's station, yet as warm and inviting as a home kitchen. The target audience includes home cooks seeking inspiration and food enthusiasts who value both efficiency and aesthetic beauty.

The visual style is **Modern Minimalism with Organic Accents**. It leverages heavy whitespace to allow high-quality food photography to serve as the primary visual driver. The interface avoids unnecessary ornamentation, focusing instead on clarity and ease of use during the cooking process. Subtle tactile elements—soft shadows and precise typography—create a sense of high-end culinary expertise.

## Colors

This design system utilizes a palette inspired by fresh ingredients and classic culinary tools. 

- **Primary (Basil Green):** Used for primary actions, success states, and brand identifiers. It represents freshness and vitality.
- **Secondary (Warm Parchment):** The foundation of the UI. This off-white shade reduces eye strain compared to pure white and evokes the texture of a physical cookbook.
- **Tertiary (Tomato Red):** Reserved for accent elements, highlights, and secondary calls to action. It provides a warm, appetizing contrast to the green.
- **Neutral (Charcoal):** Used for high-contrast typography and deep structural elements.

Backgrounds should default to `parchment` for the main canvas, with `white` (#FFFFFF) reserved for elevated cards to create subtle depth.

## Typography

The typography strategy pairs the authoritative, literary feel of **Source Serif 4** with the contemporary, highly legible **Plus Jakarta Sans**. 

- **Headlines:** Use the serif face for recipe titles, section headers, and brand moments to convey culinary tradition and expertise.
- **Body & Instructions:** Use the sans-serif face for all functional text, recipe steps, and ingredient lists. Its open counters ensure readability even on mobile devices in a kitchen environment.
- **Micro-copy:** Use semi-bold or bold weights of the sans-serif for labels, tags, and button text to ensure they stand out against the parchment background.

## Layout & Spacing

The design system employs a **Fixed Grid** on desktop (max-width 1280px) and a **Fluid Grid** on mobile devices. 

- **Rhythm:** A strict 8px baseline grid ensures vertical harmony. 
- **Desktop:** 12-column layout with 24px gutters. Use wide 64px outer margins to maintain a focused, editorial feel.
- **Mobile:** 4-column layout with 16px margins.
- **Content Density:** Maintain high padding within recipe cards and instruction blocks to prevent the UI from feeling cluttered. AI-generated responses should be presented with generous line-height and paragraph spacing to aid scannability while cooking.

## Elevation & Depth

Hierarchy is established through **Tonal Layers** and **Ambient Shadows**. 

- **Level 0 (Base):** Warm Parchment background.
- **Level 1 (Cards):** Pure white surfaces with a very soft, diffused shadow (Blur: 20px, Y: 4px, Color: rgba(17, 24, 39, 0.05)).
- **Level 2 (Interactive):** Elements like active input fields or hovered cards gain a slightly deeper shadow (Blur: 30px, Y: 8px, Color: rgba(17, 24, 39, 0.08)) and a 1px border in `sage-tint`.
- **Level 3 (Modals):** High-elevation surfaces with a 15% backdrop blur to maintain context of the underlying recipe.

## Shapes

The shape language is "Softly Organic." A standard 0.5rem (8px) radius is applied to buttons, input fields, and small containers. Larger components like recipe cards and image containers use 1rem (16px) or 1.5rem (24px) to emphasize the approachable and friendly nature of the AI assistant. 

Avatars and category tags (e.g., "Vegan," "Quick") should use pill-shaped (full) rounding to differentiate them from functional UI components.

## Components

- **Buttons:** Primary buttons use `basil-green` with white text. Secondary buttons use a `sage-tint` background with `basil-green` text. All buttons feature a 0.5rem radius and a slight scale-down effect (0.98) on click for tactility.
- **Input Fields:** AI prompt fields and search bars should be large (56px height) with a white background, `charcoal` text, and a `sage-tint` border. The focus state transitions the border to `basil-green`.
- **Recipe Cards:** These are the hero components. They feature a top-down food image with a 1:1 aspect ratio, followed by a `Source Serif 4` title and meta-data (time, difficulty) in `Plus Jakarta Sans`. 
- **Chips/Tags:** Used for dietary preferences. These are pill-shaped with a low-saturation `sage-tint` background and `basil-green` labels.
- **Checkboxes:** Styled with the `basil-green` primary color and a soft rounding (4px) to avoid a harsh technical look.
- **Cooking Mode List:** When a recipe is active, list items should be large with high touch targets. Completed steps are indicated by a strike-through and a change in text color to `slate-gray`.