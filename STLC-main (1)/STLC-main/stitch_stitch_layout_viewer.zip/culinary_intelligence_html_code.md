# Culinary Intelligence - Web Application HTML

This document contains the clean, production-ready HTML for the "Culinary Intelligence" web application. All screens use Tailwind CSS for styling and are built for a desktop experience.

## 1. Home Page (Home - Culinary Intelligence)
{{DATA:SCREEN:SCREEN_6}}

## 2. Pantry Input (What's in your fridge?)
{{DATA:SCREEN:SCREEN_5}}

## 3. Recipe Discovery (Recipe Discoveries)
{{DATA:SCREEN:SCREEN_4}}

## 4. Recipe Detail (Recipe: Herb-Crusted Salmon)
{{DATA:SCREEN:SCREEN_2}}

---
*Note: To use this code locally, ensure you have Tailwind CSS included in your project.*